# IBM-SMART-INTERNS
Welcome to our data-driven exploration of electricity consumption patterns in India for the years 2019 and 2020. In this GitHub repository, we delve into a comprehensive analysis of consumption trends and their underlying drivers using data analytics techniques and Tableau visualizations

# Tableau - links
# Dashboard -1
https://public.tableau.com/app/profile/brindha.s3501/viz/Ibmsmartinternsproject-Electricityconsumption-dash1/Dashboard1?publish=yes

# Dashboard-2
https://public.tableau.com/app/profile/brindha.s3501/viz/Ibmsmartinternsproject-Electricityconsumption-dash2/Dashboard2?publish=yes

# Story-
https://public.tableau.com/app/profile/brindha.s3501/viz/Ibmsmartinternsproject-Electricityconsumption-story/Story2?publish=yes

